%function main
clear all
close all
clc

%load image 
filename = './Mosaic_floor.png';
img = imread(filename);
figure(1)
imshow(img)
title('original image')

% paramters
lambda = 6;
beta= 5;
mu = 4;

S = HMRTV(img,lambda,beta,mu);
figure(2),imshow(uint8(S))
title('smoothed image')



